package com.lowdragmc.photon.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class PhotonClientProxy {

    /**
     * should be called when Minecraft is prepared.
     */
    public static void init() {
    }

}

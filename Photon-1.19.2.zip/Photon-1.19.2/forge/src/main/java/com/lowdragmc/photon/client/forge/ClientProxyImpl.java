package com.lowdragmc.photon.client.forge;

import com.lowdragmc.photon.forge.CommonProxyImpl;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;


@OnlyIn(Dist.CLIENT)
public class ClientProxyImpl extends CommonProxyImpl {

    public ClientProxyImpl() {
        super();

    }

}

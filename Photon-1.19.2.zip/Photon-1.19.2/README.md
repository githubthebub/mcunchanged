# Photon
Photon is a VFX (visual effect) editor mod developed for minecraft which is inspired by unity.

It includes unity's particle system and the trailing system. Can help mod creators to create effects for their contents, and players can also enjoy effects by command.

Its original intention is to let players who love vfx, not be confused by technical skill and math problems. Its creativity allows you to make various dream scenarios!!



Discord: https://discord.com/invite/sDdf2yD9bh

Github: https://github.com/Low-Drag-MC/Photon

Video: https://youtu.be/rdB0qVXRgaY



There will be video tutorials in details in the future.
